package exceptions;

public class ExceptionMarket extends Exception{

	
	
}
