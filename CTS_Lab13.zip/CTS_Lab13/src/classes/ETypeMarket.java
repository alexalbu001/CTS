package classes;

public enum ETypeMarket {
BEAUTY, DECORATION, DRESS
}
