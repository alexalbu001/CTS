package state;

public interface IState {
    public void act(String task);
}
