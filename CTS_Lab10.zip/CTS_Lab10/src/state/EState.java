package state;

public enum EState {
    WORKING, VACATION, AWAY;
}
