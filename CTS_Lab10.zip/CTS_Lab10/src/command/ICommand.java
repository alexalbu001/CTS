package command;

public interface ICommand {

    void process();
}
