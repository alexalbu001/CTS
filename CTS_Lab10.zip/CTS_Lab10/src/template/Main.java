package template;

public class Main {
    public static void main(String[] args) {
        ATemplateProcedure aTemplateProcedure = new InsuranceProcedure();
        aTemplateProcedure.getInsurance();
    }
}
