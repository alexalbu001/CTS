package factoryMeth;

public interface IWeapon {
	public void power();
}
