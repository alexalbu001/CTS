package factoryMeth;

public interface IFactory {
		
	public IWeapon getWeapon(int price);
}
