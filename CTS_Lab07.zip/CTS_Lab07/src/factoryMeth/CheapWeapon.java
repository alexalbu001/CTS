package factoryMeth;

public class CheapWeapon implements IWeapon{

	@Override
	public void power() {
		// TODO Auto-generated method stub
		System.out.println("This weapon has no power");
	}
	
	
}
