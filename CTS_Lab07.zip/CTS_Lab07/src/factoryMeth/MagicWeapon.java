package factoryMeth;

public class MagicWeapon implements IWeapon{
	
	@Override
	public void power() {
		// TODO Auto-generated method stub
		System.out.println("This weapon has magic power");
	}
}
