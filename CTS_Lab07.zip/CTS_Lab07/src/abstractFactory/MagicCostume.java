package abstractFactory;

public class MagicCostume implements ICostume{

	@Override
	public void protection() {
		// TODO Auto-generated method stub
		System.out.println("This costume is magical");
	}
		
}
