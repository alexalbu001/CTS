package abstractFactory;

public class CheapCostume implements ICostume{

	@Override
	public void protection() {
		// TODO Auto-generated method stub
		System.out.println("This costume is cheap");
	}

}
