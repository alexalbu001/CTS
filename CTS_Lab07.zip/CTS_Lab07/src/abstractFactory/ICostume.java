package abstractFactory;

public interface ICostume {
	public void protection();
}
