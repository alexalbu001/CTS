package abstractFactory;

public interface IWeapon {
	public void power();
}
