package adapter;

public interface IDiscountA {
	public double calculateDiscountA(int noOrders);
}
