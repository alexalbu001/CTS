package adapter;

public interface IDiscountB {
	public double calculateDiscountB(Customer c);
}
