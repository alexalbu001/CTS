package proxy;

public interface ILoginModule {
	public boolean login(String username, String password);
}
