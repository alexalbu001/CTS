package decorator;

public abstract class APizza {
		
	private String name;
	private float price;
	public abstract String getIngredient();
	public abstract float getCost();
	
}
