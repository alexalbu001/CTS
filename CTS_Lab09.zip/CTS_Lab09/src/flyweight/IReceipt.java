package flyweight;

public interface IReceipt {
	public void printReceipt(ReceiptData data);
}
