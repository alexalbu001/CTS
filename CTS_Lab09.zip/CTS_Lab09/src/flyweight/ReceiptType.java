package flyweight;

public enum ReceiptType {
	
	FORMAT1,FORMAT2,FORMAT3
}
